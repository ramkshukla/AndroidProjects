package com.example.task2

import android.content.ClipData
import java.io.FileDescriptor

interface MyInterface {
    fun onItemClick(title:String,desc:String)
}