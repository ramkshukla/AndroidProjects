package com.example.task2
data class News(val totalResults: Int, val articles:List<Articles>)